"""
Simplified ℓ‑diversity masking utilities.

For each quasi‑identifier *column* (treated separately), if the
column‑level class contains fewer than ℓ distinct sensitive values,
the sensitive attribute in every row of that class is replaced by
a sentinel (default: "*").  A row is suppressed if it fails the rule
in *any* of its quasi‑identifier columns.
"""

from typing import List

import pandas as pd


__all__ = ["l_diversity_mask"]


def l_diversity_mask(
        df: pd.DataFrame,
        quasi_cols: List[str],
        sensitive_col: str,
        l: int,
        sentinel: str = "*",
) -> pd.DataFrame:
    """
    Enforce column‑wise ℓ‑diversity suppression (mask when diversity < ℓ).

    Parameters
    ----------
    df : pd.DataFrame
        Input data.
    quasi_cols : List[str]
        Columns that form the equivalence class (quasi‑identifiers).
        Each column is evaluated independently; rows are suppressed if
        *any* column’s class fails ℓ‑diversity.
        If an empty list is supplied, masking is decided **globally** on the
        frequency of the sensitive values.
    sensitive_col : str
        Column containing the sensitive attribute.
    l : int
        Mask when a class contains **at least** this many distinct sensitive values.
    sentinel : str, default="*"
        Replacement string used for suppression.

    Returns
    -------
    pd.DataFrame
        Same shape as `df`.  Rows are suppressed if they belong to at least
        one class (under any quasi‑identifier column, or globally when no
        quasi‑identifiers are supplied) with < ℓ distinct sensitive values.
    """
    # Work on a copy to preserve the original DataFrame
    out = df.copy()

    # -------------------- GLOBAL (no quasi‑identifiers) --------------------
    if not quasi_cols:
        # Count frequency of each sensitive value across the entire column
        freq = out[sensitive_col].map(out[sensitive_col]
                                      .value_counts(dropna=False))
        # Mask values whose frequency is less than ℓ
        needs_suppression = freq < l
        out.loc[needs_suppression, sensitive_col] = sentinel
        return out
    # ----------------------------------------------------------------------

    # ── Column‑wise ℓ‑diversity checks ──────────────────────────────────
    needs_suppression = pd.Series(False, index=out.index)

    for col in quasi_cols:
        diversity_size = (
            out.groupby(col, dropna=False)[sensitive_col]
            .transform("nunique")
        )
        needs_suppression |= diversity_size < l
    # -------------------------------------------------------------------

    out.loc[needs_suppression, sensitive_col] = sentinel
    return out