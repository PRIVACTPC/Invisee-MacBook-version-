from pathlib import Path
from typing import Callable, Iterable

import pandas as pd


class DataRepository:
    def __init__(self, frame: pd.DataFrame, *, source: Path | None = None):
        self._frame = frame.copy()
        self._source = source

    # ---------------------------------------------------------------------
    # Constructors / loaders
    # ---------------------------------------------------------------------
    @classmethod
    def from_file(
            cls,
            file_path: str | Path,
            *,
            usecols: Iterable[str] | None = None,
            **read_kwargs,
    ) -> "DataRepository":
        path = Path(file_path).expanduser().resolve()
        suffix = path.suffix.lower()

        # auto-detect columns containing "date" to parse as datetime
        date_cols = [c for c in usecols] if usecols is not None else []
        date_cols = [c for c in date_cols if "date" in c.lower()]

        if suffix == ".csv":
            df = pd.read_csv(path, usecols=usecols, parse_dates=date_cols or None, **read_kwargs)
        elif suffix in {".xlsx", ".xls"}:
            df = pd.read_excel(path, usecols=usecols, engine="openpyxl", parse_dates=date_cols or None, **read_kwargs)
        else:
            raise ValueError(f"Unsupported file extension '{path.suffix}'.")

        return cls(df, source=path)

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------
    @property
    def frame(self) -> pd.DataFrame:
        """Return a defensive copy of the underlying DataFrame."""
        return self._frame.copy()

    # ------------------------------------------------------------------
    # Transformations – all copy‑on‑write unless explicitly documented
    # ------------------------------------------------------------------
    def apply(self, func: Callable[[pd.DataFrame], pd.DataFrame]) -> "DataRepository":
        """Apply a function that transforms the DataFrame."""
        new_df = func(self._frame.copy())
        if len(new_df) != len(self._frame):
            raise ValueError("Transform must preserve row count; use `filter_rows` to drop rows.")
        return DataRepository(new_df)

    def rename_columns(self, mapping: dict[str, str]) -> "DataRepository":
        """Return a new repository with columns renamed as per the mapping."""
        return DataRepository(self._frame.rename(columns=mapping))

    def filter_rows(self, predicate: Callable[[pd.DataFrame], pd.Series]) -> "DataRepository":
        """Return a new repository that only keeps rows where predicate is True."""
        mask = predicate(self._frame)
        if mask.dtype != bool or mask.size != self._frame.shape[0]:
            raise ValueError("Predicate must return a boolean Series aligned with the DataFrame.")
        return DataRepository(self._frame.loc[mask].copy())

    def clone(self) -> "DataRepository":
        """Return a new DataRepository with a deep copy of the frame."""
        return DataRepository(self._frame.copy(), source=self._source)

    def sort_by_column(self, column: str, ascending: bool = True) -> "DataRepository":
        """Return a new repository sorted by the specified column."""
        df_sorted = self._frame.sort_values(by=column, ascending=ascending).reset_index(drop=True)
        clone = self.clone()
        clone._frame = df_sorted
        return clone

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------
    def save_csv(self, file_path: str | Path, **kwargs) -> Path:
        path = Path(file_path).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        self._frame.to_csv(path, index=False, **kwargs)
        return path

    def save_parquet(self, file_path: str | Path, **kwargs) -> Path:
        path = Path(file_path).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        self._frame.to_parquet(path, index=False, **kwargs)
        return path

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self._frame)

    def __repr__(self) -> str:
        return f"DataRepository(rows={len(self)}, cols={self._frame.shape[1]})"
