import pandas as pd


def compute_distribution(series):
    """
    Return normalized value distribution for a column.
    """
    return series.value_counts(normalize=True).sort_index()


def total_variation_distance(p, q):
    """
    Compute the total variation distance (TVD) between two distributions.
    """
    return 0.5 * sum(abs(p_i - q_i) for p_i, q_i in zip(p, q))


def t_closeness_check(df, quasi_cols, sensitive_col, t):
    """
    Return a list of violating index groups (one per violating equivalence class).
    Groups with TVD > t are considered privacy violations.
    """
    global_dist = compute_distribution(df[sensitive_col])
    violations = []

    for name, group in df.groupby(quasi_cols):
        group_dist = compute_distribution(group[sensitive_col])

        # Align indices so that all categories match
        aligned_index = global_dist.index.union(group_dist.index)
        global_aligned = global_dist.reindex(aligned_index, fill_value=0)
        group_aligned = group_dist.reindex(aligned_index, fill_value=0)

        tvd = total_variation_distance(global_aligned.values, group_aligned.values)

        print(f"[DEBUG] Group {name} --> TVD = {tvd:.4f}")

        #  Standard logic: mask if TVD > t
        if tvd > t:
            violations.append(group.index)

    return violations


def apply_t_closeness(df, quasi_cols, sensitive_col, t):
    """
    Apply t-closeness masking by replacing sensitive values with "***"
    in any group that violates the t-closeness threshold.
    """
    df = df.copy()
    violating_groups = t_closeness_check(df, quasi_cols, sensitive_col, t)

    for group_index in violating_groups:
        df.loc[list(group_index), sensitive_col] = "***"

    return df
